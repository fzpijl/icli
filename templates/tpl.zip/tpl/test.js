const add = (a) => a
describe('a test', () => {
    test('test add', () => {
        expect(add(5)).toBe(5)
        console.log('end')
    })
    test('test add', () => {
        expect(add(5)).toBe(5)
        console.log('end1')
    })
})
while (true) {
    console.log('hi')
}
