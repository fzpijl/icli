const { spawn } = require('child_process')
const path = require('path')

const ls = spawn('node', ['node_modules/jest/node_modules/jest-cli/bin/jest'], {
    cwd: __dirname,
    stdio: [process.stdin, process.stdout, process.stderr]
})



ls.on('close', (code) => {
    console.log(`子进程退出，退出码 ${code}`);
});

