const add = (a) => a

setTimeout(() => {
    console.log('iris-view in child_process')
}, 1000 * 20)

describe('a test', () => {
    test('test add', () => {
        expect(add(5)).toBe(5)
        console.log('iris-view in test')
    })
    test('test add', () => {
        expect(add(5)).toBe(5)
        console.log('end1')
    })
})


const { app } = require('XRWeb');
global.app = app
const XRVue = require('./main.js').default
const TWEEN = require('@tweenjs/tween.js')
function log(...params) {
    console.log('iris-view : ', ...params)
}


const w = app.getWindowById('w1')
let c = w.getElementById('container')

const ss = w.getElementById('ss')
let num = 0
ss.on('click', function (e) {
    if (e.clickState !== 'up') return // down repeat up
    num++
    console.log(num, e, 'iris-view')
    e.stopPropagation()
})

const Button = {
    template: `
        <primitive :geometry="geo" :color="[Math.random(),Math.random(),Math.random()]" @click="clickHandler"></primitive>
    `,
    props:[ 'geo'],
    methods: {
        clickHandler(e) {
            if (e.clickState !== 'up') return //只在click事件的up状态上触发
            this.stop()
            this.disableParentLayout()
            let startAmn = this.createAnm(this.scale, {value: 1.2})
            let endAmn = this.createAnm(this.scale, {value: 1})
            startAmn.chain(endAmn)
            startAmn.start()
            this.animate()
        },
        createAnm(from, to, duration = 200) {
            const group = this.tweenGroup, update = this.updateElm.bind(this)
            return new TWEEN.Tween(from, group).to(to, duration).easing(TWEEN.Easing.Quadratic.Out).onUpdate(update)
        },
        updateElm() {
            //改变元素的scale属性
            this.vnode.elm.scale = new Array(3).fill(this.scale.value)
        },
        animate() {
            clearInterval(this.anmTimer)
            this.anmTimer = setInterval(() => this.animate(), 17)

            const gono = this.tweenGroup.update()
            if(!gono) clearInterval(this.anmTimer)
        },
        disableParentLayout() {
            this.vnode.elm.parent.autoRelayout = false
        },
        stop() {
            this.tweenGroup.removeAll()
        }

    },
    beforeCreate() {
        //实例上添加一些非响应式属性
        this.tweenGroup = new TWEEN.Group()
        this.scale = {value: 1}
    }
}

const Panel = {
    template: `<flow-layout :scale="[2, 2, 2]" :track-size="[5, 5, 5]" :gap="[0.5, 0.5]">
        <button geo="cube" v-for="item in list"></button>
    </flow-layout>`,
    data() {
        return {
            list: new Array(9)
        }
    },
    components: {Button}
}


new XRVue({
    data() {
        return {
            list: [
                {
                    position: [1, 1, 0],
                    color: [1, 0, 0],
                    scale: [1, 1, 1]
                }
            ]
        }
    },
    components: { Button, Panel },
    template: `<container>
       <panel></panel>
       <primitive v-for="item in list" :position="item.position" :scale="item.scale" :color="item.color" geometry='sphere' :opacity="1"></primitive>
    </container>`,
    el: c,
    mounted() {
        log('mounted')
        setInterval(() => {
            // let color = [Math.random(), Math.random(), Math.random()]
            // this.color = color
            // let a = Math.random()
            // this.scale = Array.from([a, a, a], (a) => a * 5)
            // this.position = Array.from([Math.random() * 2 - 1, Math.random() * 2 - 1, Math.random() * 2 - 1], a => a * 5)
            let n = Math.random() * 2 | 0, r = (n) => Math.random() * n, p = (n) => (Math.random() * 2 - 1) * n * 3
            const list = []
            while (n--) {
                list.push({
                    position: [p(5), p(5), p(5)],
                    color: [r(1), r(1), r(1)],
                    scale: new Array(3).fill(r(8))
                })
            }
            this.list = list
        }, 200)
    },
    beforeMount() {
        log(this.$data)
        log('beforeMount....')
    },
    created() {
        log('beforeCreate....')
    }
})


