const path = require('path')
console.log(path.resolve())